const myName = {};
myName.name = "Максим";
let age = 29;
myName.name = "Maxim";
//console.log(myName.name, age);
const header = document.querySelector("#header");
const testBtn = document.querySelector('#testBtn');
const navLinks = document.querySelectorAll("._nav__link")
console.log(header);












window.addEventListener("scroll", function() {
    let scrollPos = window.scrollY;
    console.log(scrollPos);
    header.classList.add('red');
    if(scrollPos>0) {
        header.classList.add('red');
    }
    else {
        header.classList.remove('red');
    }
});
testBtn.addEventListener("click", function()
{
    console.log('clicked');
});

navLinks.addEventListener("click", function()
{
    console.log('link clicked');
});

for(let navItem of navLinks){
    
}